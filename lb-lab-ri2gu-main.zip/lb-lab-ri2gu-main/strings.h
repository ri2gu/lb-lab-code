void strings_task_1(char *buffer);
void strings_task_2(char *buffer);
char *strings_task_3(char *buffer);