void pointers_task_1(int *a, int *b);
int *pointers_task_2();
